<template>
		<div class='app_center'>
      <div class='center_banner'>
          <img src="https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1495103770&di=2080756a519276466fde89c1bc70cedc&src=http://img.zcool.cn/community/0155fd580d9db9a84a0e282b276e3c.jpg@900w_1l_2o_100sh.jpg"> 
      </div>
      <div class='center_ad'>

      </div>
    </div>
</template>


<script type="text/javascript">
	export default({
		data: {

		},
		methods: {

		}
	});
</script>

<style type="text/css">
.app_center {
  background-color: #f5f5f5;
  height: 700px;
}
.center_banner img {
  padding: 0;
  margin: 0;
}
.center_ad {
  margin-top: 0;
  padding-top: 0;
  background-color: #e8e8e8;
  height: 40px;
}
</style>